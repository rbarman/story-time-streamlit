from dataclasses import dataclass
from enum import Enum
import os

class ModelProvider(Enum):
    GROQ = "groq"
    OPENAI = "openai"
    STABILITY_AI = "stability_ai"  # https://stability.ai/stable-image

class ModelTask(Enum):
    IMAGE = "image_generation"
    TEXT = "text_generation"

@dataclass
class ModelMeta:
    url: str
    api_key: str
    model: str
    provider: ModelProvider
    task: ModelTask

# API Keys:
groq_key = os.getenv("GROQ_API_KEY")
openai_key = os.getenv("OPENAI_API_KEY")    

llama3 = ModelMeta(
    url="https://api.groq.com/openai/v1/chat/completions",
    api_key=groq_key,
    model="llama3-70b-8192",
    provider=ModelProvider.GROQ,
    task=ModelTask.TEXT
)

dall_e2 = ModelMeta(
    url="https://api.openai.com/v1/images/generations",
    api_key=openai_key,
    model="dall-e-2",
    provider=ModelProvider.OPENAI,
    task=ModelTask.IMAGE
)

dall_e3 = ModelMeta(   
    url="https://api.openai.com/v1/images/generations",
    api_key=openai_key,
    model="dall-e-3",
    provider=ModelProvider.OPENAI,
    task=ModelTask.IMAGE
)