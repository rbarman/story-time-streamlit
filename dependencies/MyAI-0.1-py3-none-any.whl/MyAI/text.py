import requests
import json
from .model import ModelMeta, llama3


# Response status code: 401
# Response content: b'{"error":{"message":"Invalid API Key","type":"invalid_request_error","code":"invalid_api_key"}}

# TODO: add an expected schema check?
def call_chat_completion(
        prompt: str, 
        user_input: str = None, 
        return_structured_output: bool = False,
        model_meta: ModelMeta = llama3
    ) -> str:
    
    payload = {
        'model': model_meta.model,
        # "response_format": {
        #     "type": "json_object"
        # },
        'messages': [
            {'role': 'system', 'content': prompt},
            # {'role': 'user', 'content': user_input}
        ]
    }
    if user_input:
        payload['messages'].append({'role': 'user', 'content': user_input})
    if return_structured_output:
        payload['response_format'] = {
            "type": "json_object"
        }

    response = requests.post(
        model_meta.url,
        json=payload,
        headers={
            'Content-Type': 'application/json',
            'Authorization': f'Bearer {model_meta.api_key}'
        }
    )
    print(f"Response status code: {response.status_code}")
    print(f"Response content: {response.content}")
    response.raise_for_status()  # Raise an exception for 4xx or 5xx status codes

    content = response.json().get('choices', [{}])[0].get('message', {}).get('content')
    if not content:
        raise ValueError("No content found in the response.")

    if return_structured_output:
        content_dict = json.loads(content)
        return content_dict
    else:
        return content

if __name__ == '__main__':
    prompt = "You are a friendly assistant who helps people with their daily tasks."
    user_input = "Hello"
    response = call_chat_completion(prompt, user_input)
    print(response)