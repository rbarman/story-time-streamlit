from model import ModelMeta, dall_e3
import requests

# Response status code: 400
# Response content: b'{\n  "error": {\n    "code": "content_policy_violation",\n    "message": "This request has been blocked by our content filters.",\n    "param": null,\n    "type": "invalid_request_error"\n  }\n}\n'
# 2024-06-14 21:19:40.819 Uncaught app exception

def call_image_generation(prompt: str, model_meta: ModelMeta = dall_e3) -> str:
    payload = {
        'prompt': prompt,
        'model': model_meta.model,
        'n': 1,
        # size
    }
    response = requests.post(
        model_meta.url,
        json=payload,
        headers={
            'Content-Type': 'application/json',
            'Authorization': f'Bearer {model_meta.api_key}'
        }
    )
    print(f"Response status code: {response.status_code}")
    print(f"Response content: {response.content}")
    response.raise_for_status()  # Raise an exception for 4xx or 5xx status codes
    content = response.json().get('data', [{}])[0].get('url')
    return content

if __name__ == "__main__":
    prompt = """
        You are a designer for a story telling app. You have received a caption for a story segment.
        Generate an image that best describes the caption. 
        If the caption contains sensitive or graphic information then create the image in a cartoon form to avoid offensive material

        Caption: orensic investigator Hawk kneels beside the young victim, his gloved hands delicately collecting evidence, amidst the chaos and debris of the crime scene.
    """
    image_url = call_image_generation(prompt)
    print(image_url)