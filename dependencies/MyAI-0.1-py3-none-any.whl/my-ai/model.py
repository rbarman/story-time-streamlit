from dataclasses import dataclass

@dataclass
class ModelMeta:
    url: str
    api_key: str
    model: str
    provider: str

# https://stability.ai/stable-image

llama3 = ModelMeta(
    url="https://api.groq.com/openai/v1/chat/completions",
    api_key="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",
    model="llama3-70b-8192",
    provider="groq"
)

dall_e2 = ModelMeta(
    url="https://api.openai.com/v1/images/generations",
    api_key="sk-proj-ihfnDASmuxw3KHufpxm9T3BlbkFJuNmwBoCkqixD0zkRWOvR",
    model="dall-e-2",
    provider="openai"
)

dall_e3 = ModelMeta(   
    url="https://api.openai.com/v1/images/generations",
    api_key="sk-proj-ihfnDASmuxw3KHufpxm9T3BlbkFJuNmwBoCkqixD0zkRWOvR",
    model="dall-e-3",
    provider="openai"
)